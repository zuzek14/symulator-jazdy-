let car=document.getElementById("car");
let enemy=document.getElementById("enemy");

let speedText=document.getElementById("speed");
let fuelText=document.getElementById("fuel");
let scoreText=document.getElementById("score");
let kmText=document.getElementById("km");

let lines=document.querySelectorAll(".line");

let speed=0;
let position=50;
let fuel=100;
let score=0;
let km=0;

let enemyY=-150;


document.addEventListener("keydown",function(e){

if(e.key=="ArrowUp"){
speed+=5;
}

if(e.key=="ArrowDown"){
speed-=5;
}

if(e.key=="ArrowLeft"){
position-=3;
}

if(e.key=="ArrowRight"){
position+=3;
}


if(speed<0) speed=0;
if(speed>200) speed=200;

if(position<40) position=40;
if(position>60) position=60;


car.style.left=position+"%";

speedText.innerHTML=speed;

});



document.getElementById("tank").onclick=function(){

fuel=100;

};



let night=false;

document.getElementById("night").onclick=function(){

night=!night;

if(night){

document.getElementById("game").style.background="#111";

}else{

document.getElementById("game").style.background="#70cfff";

}

};



function game(){


lines.forEach(function(line){

let y=Number(line.dataset.y||0);

y+=speed;

if(y>800){
y=-200;
}

line.dataset.y=y;

line.style.transform=
"translateY("+y+"px)";

});



enemyY+=speed;

if(enemyY>900){

enemyY=-200;

enemy.style.left=
(Math.random()*20+40)+"%";

score++;

scoreText.innerHTML=score;

}


enemy.style.top=enemyY+"px";


if(speed>0){

fuel-=0.02;

km+=speed/500;

}


if(fuel<0){

fuel=0;
speed=0;

}


fuelText.innerHTML=Math.floor(fuel);
kmText.innerHTML=km.toFixed(1);



requestAnimationFrame(game);

}


game();